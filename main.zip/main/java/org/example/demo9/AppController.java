package org.example.demo9;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import org.springframework.web.servlet.ModelAndView;


import java.util.List;


/**
 * Контроллер приложения для работы с клиентами, турами и бронированиями.
 */
@Controller
public class AppController {

    @Autowired
    private ClientService clientService;

    @Autowired
    private TourService tourService;

    @Autowired
    private BookingService bookingService;

    @Autowired
    private ChatService chatService;

    /**
     * Обрабатывает запрос на открытие страницы входа.
     *
     * @return имя представления страницы входа.
     */
    @GetMapping("/login")
    public String login() {
        return "login";
    }

    /**
     * Отображает домашнюю страницу для клиентов после входа в систему.
     *
     * Метод также заполняет модель необходимыми данными на основе ключевого слова для поиска.
     *
     * @param model модель для передачи данных в представление.
     * @param keyword ключевое слово для фильтрации данных (может быть null).
     * @return имя представления домашней страницы для клиентов.
     */
    @GetMapping("/client/home")
    public String clientHome(Model model, @Param("keyword") String keyword) {
        populateTourModel(model, keyword);
        return "clientHome";
    }

    /**
     * Метод для отображения главной страницы приложения.
     *
     * @return имя представления главной страницы.
     */
    @RequestMapping("/")
    public String index() {
        return "homePage";
    }

    /**
     * Отображает список клиентов с возможностью поиска по ключевому слову.
     *
     * Метод получает список клиентов от сервиса, основываясь на переданном ключевом слове,
     * добавляет клиентов в модель и возвращает представление для отображения списка клиентов.
     *
     * @param model модель для передачи данных в представление.
     * @param keyword ключевое слово для поиска клиентов (может быть null).
     * @return имя представления списка клиентов.
     */
    @RequestMapping("/clients")
    public String openClient(Model model, @Param("keyword") String keyword) {
        List<Client> clientList = clientService.getAllClient(keyword);
        model.addAttribute("clientList", clientList);
        model.addAttribute("keyword", keyword);
        return "client";
    }

    /**
     * Обрабатывает запрос на открытие страницы туров.
     *
     * Получает список туров на основе переданного ключевого слова, вычисляет среднюю стоимость
     * туров и количество туров по видам транспорта, добавляя эти данные в модель для отображения
     * на странице.
     *
     * @param model модель, используемая для передачи данных на представление.
     * @param keyword ключевое слово для фильтрации туров (может быть null).
     * @return имя представления списка туров.
     */
    @RequestMapping("/tours")
    public String openTour(Model model, @Param("keyword") String keyword) {
        populateTourModel(model, keyword);
        return "tour";
    }

    /**
     * Заполняет модель данными о турах и дополнительной информацией.
     *
     * Этот метод получает список туров от сервиса, добавляет информацию о турах, включая
     * общее количество и среднюю цену, к модели.
     *
     * @param model модель, в которую добавляются данные о турах.
     * @param keyword ключевое слово для фильтрации туров (может быть null).
     */
    private void populateTourModel(Model model, String keyword) {
        List<Tour> tourList = tourService.getAllTours(keyword);
        model.addAttribute("tourList", tourList);
        model.addAttribute("keyword", keyword);
        model.addAttribute("totalTours", tourList.size());
        model.addAttribute("averagePrice", tourService.calculateAveragePrice(tourList));
        model.addAttribute("transportCounts", tourService.getCountsByTransport(tourList));
    }
    /**
     * Метод для отображения списка бронирований с возможностью поиска по ключевому слову.
     *
     * @param model модель для передачи данных в представление.
     * @param keyword ключевое слово для поиска бронирований.
     * @return имя представления списка бронирований.
     */
    @RequestMapping("/booking")
    public String openBooking(Model model, @Param("keyword") String keyword) {
        List<Booking> bookingList = bookingService.getAllBooking(keyword);
        model.addAttribute("bookingList", bookingList);
        model.addAttribute("keyword", keyword);
        return "booking";
    }

    /**
     * Метод для отображения информации о себе.
     *
     * @param model модель для передачи данных в представление.
     * @return имя представления о себе.
     */
    @RequestMapping ("/AboutMe")
    public String openAboutMe(Model model) {
        return "about_me";
    }

    /**
     * Метод для отображения формы создания нового клиента.
     *
     * @param model модель для передачи данных в представление.
     * @return имя представления формы нового клиента.
     */
    @RequestMapping("/clients/new")
    public String newClient(Model model) {
        model.addAttribute("client", new Client());
        return "new_client";
    }

    /**
     * Метод для сохранения нового клиента.
     *
     * @param client объект клиента для сохранения.
     * @return перенаправление на список клиентов.
     */
    @PostMapping("/clients/save")
    public String saveClient(@ModelAttribute("client") Client client) {
        clientService.save(client);
        return "redirect:/clients";
    }

    /**
     * Метод для отображения формы редактирования клиента.
     *
     * @param id идентификатор клиента.
     * @return представление формы редактирования клиента.
     */
    @RequestMapping("/clients/edit/{id}")
    public ModelAndView editClient(@PathVariable Integer id) {
        ModelAndView view = new ModelAndView("edit_client");
        Client client = clientService.get(id);
        view.addObject("client", client);
        return view;
    }

    /**
     * Метод для удаления клиента.
     *
     * @param id идентификатор клиента.
     * @return перенаправление на список клиентов.
     */
    @RequestMapping("/clients/delete/{id}")
    public String deleteClient(@PathVariable Integer id) {
        clientService.delete(id);
        return "redirect:/Client";
    }

    /**
     * Метод для отображения формы создания нового тура.
     *
     * @param model модель для передачи данных в представление.
     * @return имя представления формы нового тура.
     */
    @RequestMapping("/tours/new")
    public String newTour(Model model) {
        model.addAttribute("tour", new Tour());
        return "new_tour";
    }

    /**
     * Метод для сохранения нового тура.
     *
     * @param tour объект тура для сохранения.
     * @return перенаправление на список туров.
     */
    @PostMapping( "/tours/save")
    public String saveTour(@ModelAttribute("tour") Tour tour) {
        tourService.save(tour);
        return "redirect:/tours";
    }

    /**
     * Метод для отображения формы редактирования тура.
     *
     * @param id идентификатор тура.
     * @return представление формы редактирования тура.
     */
    @RequestMapping ("/tours/edit/{id}")
    public ModelAndView editTour(@PathVariable Integer id) {
        ModelAndView view = new ModelAndView("edit_tour");
        Tour tour = tourService.get(id);
        view.addObject("tour", tour);
        return view;
    }

    /**
     * Метод для удаления тура.
     *
     * @param id идентификатор тура.
     * @return перенаправление на список туров.
     */
    @RequestMapping ("/tours/delete/{id}")
    public String deleteTour(@PathVariable Integer id) {
        tourService.delete(id);
        return "redirect:/tours";
    }

    /**
     * Метод для отображения формы создания нового бронирования.
     *
     * @param model модель для передачи данных в представление.
     * @return имя представления формы нового бронирования.
     */
    @RequestMapping ("/booking/new")
    public String newBooking(Model model) {
        List<Tour> tourList = tourService.getAllTours(null);
        List<Client> clientList = clientService.getAllClient(null);
        model.addAttribute("tourList", tourList);
        model.addAttribute("clientList", clientList);
        model.addAttribute("booking", new Booking());
        return "new_booking";
    }

    /**
     * Метод для сохранения нового бронирования.
     *
     * @param booking объект бронирования для сохранения.
     * @param tourId идентификатор тура.
     * @param clientId идентификатор клиента.
     * @return перенаправление на список бронирований.
     */
    @PostMapping("/booking/save")
    public String saveBooking(@ModelAttribute("booking") Booking booking,
                              @RequestParam(value = "tour_id") Integer tourId,
                              @RequestParam(value = "client_id") Integer clientId) {
        Tour tour = tourService.get(tourId);
        Client client = clientService.get(clientId);
        booking.setTour(tour);
        booking.setClient(client);
        bookingService.save(booking);
        return "redirect:/booking";
    }

    /**
     * Метод для отображения формы редактирования бронирования.
     *
     * @param bookingCode код бронирования.
     * @param model модель для передачи данных в представление.
     * @return имя представления формы редактирования бронирования.
     */
    @RequestMapping("/booking/edit/{bookingCode}")
    public String editBooking(@PathVariable Integer bookingCode, Model model) {
        Booking booking = bookingService.get(bookingCode);
        List<Tour> tourList = tourService.getAllTours(null);
        List<Client> clientList = clientService.getAllClient(null);
        model.addAttribute("booking", booking);
        model.addAttribute("tourList", tourList);
        model.addAttribute("clientList", clientList);
        return "edit_booking";
    }

    /**
     * Метод для удаления бронирования.
     *
     * @param bookingCode код бронирования.
     * @return перенаправление на список бронирований.
     */
    @RequestMapping("/booking/delete/{bookingCode}")
    public String deleteBooking(@PathVariable Integer bookingCode) {
        bookingService.delete(bookingCode);
        return "redirect:/booking";
    }
    /**
     * Открывает страницу чата и отображает список чатов.
     *
     * @param model  модель для передачи данных в представление.
     * @param keyword ключевое слово для поиска чатов (может быть null).
     * @return имя представления, отображающего страницу чата.
     */
    @RequestMapping("/chat")
    public String openChat(Model model, @Param("keyword") String keyword) {
        List<Chat> chatList = chatService.getAllChat(keyword);
        model.addAttribute("chatList", chatList);
        model.addAttribute("keyword", keyword);
        return "chat";
    }

    /**
     * Открывает страницу для создания нового чата.
     *
     * @param model модель для передачи данных в представление.
     * @return имя представления, отображающего страницу создания нового чата.
     */
    @RequestMapping("/chat/new")
    public String newChat(Model model) {
        model.addAttribute("chat", new Chat());
        return "new_chat";
    }

    /**
     * Сохраняет новый чат и перенаправляет на страницу домашнего экрана клиента.
     *
     * @param chat объект чата, который нужно сохранить.
     * @return перенаправление на главную страницу клиента.
     */
    @PostMapping("/chat/save")
    public String saveChat(@ModelAttribute("chat") Chat chat) {
        chatService.save(chat);
        return "redirect:/client/home";
    }

    /**
     * Удаляет чат по его уникальному идентификатору и перенаправляет на страницу чатов.
     *
     * @param id уникальный идентификатор чата, который нужно удалить.
     * @return перенаправление обратно на страницу чатов.
     */
    @RequestMapping("/chat/delete/{id}")
    public String deleteChat(@PathVariable Integer id) {
        chatService.delete(id);
        return "redirect:/chat";
    }
}



