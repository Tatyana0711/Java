package org.example.demo9;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Data;

import java.time.LocalDate;

/**
 * Класс, представляющий сущность тура.
 * <p>
 * Этот класс соответствует таблице "Tour" в базе данных и содержит информацию о турах,
 * включая название, страну, город, даты отправления и прибытия, цену и вид транспорта.
 * </p>
 */
@Data
@Entity
public class Tour {

    /** Уникальный идентификатор тура. */
    private Integer ID;

    /** Название тура. */
    private String name;

    /** Страна назначения тура. */
    private String country;

    /** Город назначения тура. */
    private String city;

    /** Дата отправления. */
    private LocalDate departure;

    /** Дата прибытия. */
    private LocalDate arrival;

    /** Цена тура. */
    private Double price;

    /** Транспорт, используемый для тура. */
    private String transport;


    /**
     * Получает уникальный идентификатор тура.
     *
     * @return уникальный идентификатор тура.
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Integer getID(){
        return ID;
    }

}
