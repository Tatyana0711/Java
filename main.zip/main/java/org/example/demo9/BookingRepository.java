package org.example.demo9;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Интерфейс репозитория для работы с объектами типа {@link Booking}.
 * <p>
 * Этот интерфейс расширяет JpaRepository и предоставляет методы для выполнения операций CRUD
 * и дополнительных запросов к базе данных для записей о бронированиях.
 * </p>
 */
@Repository
public interface BookingRepository extends JpaRepository<Booking, Integer> {

    /**
     * Метод для поиска записей о бронированиях по ключевому слову.
     * <p>
     * Выполняет выборку бронирований, где любое из полей,
     * включая идентификатор бронирования, связанные туры и клиенты,
     * содержит заданное ключевое слово.
     * </p>
     *
     * @param keyword ключевое слово для поиска.
     * @return список найденных объектов {@link Booking}, соответствующих условию поиска.
     */
    @Query("SELECT p FROM Booking p WHERE CONCAT(p.bookingCode, p.tour, p.client) LIKE %?1%")
    public List<Booking> search (String keyword);
}
