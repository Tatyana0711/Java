package org.example.demo9;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;

/**
 * Конфигурация безопасности Spring, которая определяет аутентификацию и авторизацию для приложения.
 */
@Configuration
@EnableWebSecurity
public class SecurityConfig {

    /**
     * Создание UserDetailsService с пользователями в памяти.
     *
     * @return UserDetailsService с конфигурированными пользователями.
     */
    @Bean
    public UserDetailsService userDetailsService() {
        InMemoryUserDetailsManager manager = new InMemoryUserDetailsManager();
        manager.createUser(User.withUsername("client")
                .password(passwordEncoder().encode("2222"))
                .roles("CLIENT")
                .build());
        manager.createUser(User.withUsername("manager")
                .password(passwordEncoder().encode("1111"))
                .roles("MANAGER")
                .build());
        return manager;
    }

    /**
     * Настройка цепочки фильтров безопасности.
     *
     * @param http объект HttpSecurity, используемый для настройки параметров безопасности.
     * @return построенный объект SecurityFilterChain.
     * @throws Exception если возникла ошибка при настройке безопасности.
     */
    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                .authorizeHttpRequests(authorizeRequests -> authorizeRequests
                        .requestMatchers("/client/home").hasRole("CLIENT")
                        .requestMatchers("/").hasRole("MANAGER")
                        .anyRequest().authenticated())
                .formLogin(formLogin ->
                        formLogin
                                .loginPage("/login")
                                .permitAll()
                                .failureUrl("/login?error=true")
                                .successHandler((request, response, authentication) -> {
                                    boolean isClient = authentication.getAuthorities().stream()
                                            .anyMatch(a -> a.getAuthority().equals("ROLE_CLIENT"));
                                    if (isClient) {
                                        response.sendRedirect("/client/home");
                                    } else {
                                        response.sendRedirect("/");
                                    }
                                })
                )
                .logout(logout -> logout.permitAll());

        return http.build();
    }

    /**
     * Определяет PasswordEncoder, который используется для хэширования паролей.
     *
     * @return BCryptPasswordEncoder для шифрования паролей.
     */
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
}
