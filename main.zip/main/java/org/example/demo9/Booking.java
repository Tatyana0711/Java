package org.example.demo9;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.Data;

/**
 * Класс, представляющий собой запись о бронировании.
 * Этот класс соответствует таблице "Booking" в базе данных.
 * Он содержит информацию о клиенте и туре, связанном с данным бронированием.
 */
@Data
@Entity
public class Booking {

    /**
     * Уникальный идентификатор бронирования.
     * Автоматически генерируется при добавлении новой записи.
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer bookingCode;

    /**
     * Тур, связанный с данным бронированием.
     * Существует связь "многие к одному" с классом Tour.
     */
    @ManyToOne
    @JoinColumn(name = "tour_id")
    private Tour tour;

    /**
     * Клиент, который сделал это бронирование.
     * Существует связь "многие к одному" с классом Client.
     */
    @ManyToOne
    @JoinColumn(name = "client_id")
    private Client client;

}