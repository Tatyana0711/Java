package org.example.demo9;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

/**
 * Сервисный класс, обрабатывающий бизнес-логику для объектов бронирования.
 * Этот класс управляет взаимодействием между контроллерами и репозиторием
 * бронирований, предоставляя методы для получения, сохранения и удаления бронирований.
 */
@Service
public class BookingService {
    @Autowired
    private BookingRepository repo;

    /**
     * Получает список всех бронирований, при необходимости фильтруя их по ключевому слову.
     *
     * @param keyword ключевое слово для фильтрации (может быть null для получения всех бронирований).
     * @return список объектов {@link Booking}, соответствующих критериям поиска.
     */
    public List<Booking> getAllBooking(String keyword) {
        if (keyword != null){
            return repo.search(keyword);
        }
        return repo.findAll();
    }

    /**
     * Сохраняет объект бронирования в базе данных.
     *
     * @param booking объект бронирования, который нужно сохранить.
     */
    public void save(Booking booking) {
        repo.save(booking);
    }

    /**
     * Получает объект бронирования по его уникальному коду.
     *
     * @param bookingCode уникальный код бронирования.
     * @return объект {@link Booking}, соответствующий заданному коду.
     */
    public Booking get(Integer bookingCode) {
        return repo.findById(bookingCode).get();
    }

    /**
     * Удаляет объект бронирования по его уникальному коду.
     *
     * @param bookingCode уникальный код бронирования, которое нужно удалить.
     */
    public void delete(Integer bookingCode) {
        repo.deleteById(bookingCode);
    }
}
