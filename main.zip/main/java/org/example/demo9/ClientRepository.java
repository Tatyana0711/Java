package org.example.demo9;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Репозиторий для обработки данных клиентов.
 * <p>
 * Этот интерфейс расширяет {@link JpaRepository} и предоставляет
 * методы для доступа к объектам {@link Client} в базе данных.
 * </p>
 */
@Repository
public interface ClientRepository extends JpaRepository<Client, Integer> {

    /**
     * Ищет клиентов по ключевому слову.
     * <p>
     * Этот метод выполняет поиск клиентов, полное имя и другие данные
     * которых содержат данное ключевое слово. Поиск выполняется по
     * всем полям клиента, включая ID, имя, фамилию, отчество, дату рождения,
     * адрес, номер телефона и электронную почту.
     * </p>
     *
     * @param keyword ключевое слово для фильтрации клиентов
     * @return список клиентов, соответствующих критериям поиска
     */
    @Query("SELECT p FROM Client p WHERE CONCAT(p.ID, p.name, p.surname, p.middle_Name, p.date_of_birth, p.address, p.phone_number, p.email) LIKE %?1%")
    public List<Client> search (String keyword);
}
