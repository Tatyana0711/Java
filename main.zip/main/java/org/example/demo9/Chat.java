package org.example.demo9;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Data;

/**
 * Класс Chat представляет собой сущность чата.
 * Содержит информацию о сообщениях, номерe телефона и уникальном идентификаторе.
 */
@Data
@Entity
public class Chat {

    /**
     * Уникальный идентификатор чата.
     */
    private Integer ID;

    /**
     * Номер телефона пользователя, отправившего сообщение.
     */
    private String phone_number;

    /**
     * Текст сообщения чата.
     */
    private String message;

    /**
     * Получает уникальный идентификатор чата.
     *
     * @return уникальный идентификатор чата.
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Integer getID() {
        return ID;
    }
}
