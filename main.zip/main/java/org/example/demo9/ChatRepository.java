package org.example.demo9;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Репозиторий для работы с объектами чата.
 * Расширяет интерфейс JpaRepository для управления данными чата.
 */
@Repository
public interface ChatRepository extends JpaRepository<Chat, Integer> {

    /**
     * Ищет чаты по заданному ключевому слову.
     * Иск searching производится по номеру телефона и сообщению.
     *
     * @param keyword ключевое слово для поиска в чатах.
     * @return список чатов, соответствующих критериям поиска.
     */
    @Query("SELECT p FROM Chat p WHERE CONCAT(p.phone_number, p.message) LIKE %?1%")
    public List<Chat> search(String keyword);
}