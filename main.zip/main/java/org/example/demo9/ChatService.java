package org.example.demo9;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

/**
 * Сервисный класс для управления чатами.
 * Содержит методы для получения, сохранения и удаления сообщений чата.
 */
@Service
public class ChatService {

    @Autowired
    private ChatRepository repo;

    /**
     * Получает список чатов. Если передано ключевое слово,
     * выполняет поиск по нему.
     *
     * @param keyword ключевое слово для поиска чатов (может быть null).
     * @return список чатов.
     */
    public List<Chat> getAllChat(String keyword) {
        if (keyword != null){
            return repo.search(keyword);
        }
        return repo.findAll();
    }

    /**
     * Сохраняет чат в репозитории.
     *
     * @param chat объект чата для сохранения.
     */
    public void save(Chat chat) {
        repo.save(chat);
    }

    /**
     * Получает чат по его уникальному идентификатору.
     *
     * @param id уникальный идентификатор чата.
     * @return объект чата с заданным идентификатором.
     */
    public Chat get(Integer id) {
        return repo.findById(id).get();
    }

    /**
     * Удаляет чат по его уникальному идентификатору.
     *
     * @param id уникальный идентификатор чата для удаления.
     */
    public void delete(Integer id) {
        repo.deleteById(id);
    }
}
