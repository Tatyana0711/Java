package org.example.demo9;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

/**
 * Сервисный класс для управления клиентами.
 * <p>
 * Этот класс содержит бизнес-логику для работы с клиентами,
 * включая методы для получения, сохранения и удаления клиентов.
 * </p>
 */
@Service
public class ClientService {
    @Autowired
    private ClientRepository repo2;

    /**
     * Получает список всех клиентов или фильтрует их по ключевому слову.
     *
     * @param keyword ключевое слово для фильтрации клиентов (может быть null для получения всех клиентов).
     * @return список объектов {@link Client}, соответствующих критериям поиска.
     */
    public List<Client> getAllClient(String keyword) {
        if (keyword != null){
            return repo2.search(keyword);
        }
        return repo2.findAll();
    }

    /**
     * Сохраняет объект клиента в базе данных.
     *
     * @param client объект {@link Client}, который нужно сохранить.
     */
    public void save(Client client) {
        repo2.save(client);
    }

    /**
     * Получает объект клиента по его уникальному идентификатору.
     *
     * @param id уникальный идентификатор клиента.
     * @return объект {@link Client}, соответствующий заданному идентификатору.
     */
    public Client get(Integer id) {
        return repo2.findById(id).get();
    }

    /**
     * Удаляет объект клиента по его уникальному идентификатору.
     *
     * @param id уникальный идентификатор клиента, который нужно удалить.
     */
    public void delete(Integer id) {
        repo2.deleteById(id);
    }
}
