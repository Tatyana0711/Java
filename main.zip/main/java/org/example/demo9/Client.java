package org.example.demo9;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Data;

import java.time.LocalDate;

/**
 * Класс, представляющий собой сущность клиента.
 * <p>
 * Этот класс соответствует таблице "Client" в базе данных
 * и содержит информацию о клиенте, включая его
 * личные данные и контактную информацию.
 * </p>
 */
@Data
@Entity
public class Client {

    /** Уникальный идентификатор клиента. */
    private Integer ID;

    /** Имя клиента. */
    private String Name;

    /** Фамилия клиента. */
    private String Surname;

    /** Отчество клиента. */
    private String Middle_Name;

    /** Дата рождения клиента. */
    private LocalDate date_of_birth;

    /** Адрес клиента. */
    private String address;

    /** Номер телефона клиента. */
    private String phone_number;

    /** Электронная почта клиента. */
    private String email;

    /**
     * Получает уникальный идентификатор клиента.
     *
     * @return уникальный идентификатор клиента.
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Integer getID(){
        return ID;
    }

}