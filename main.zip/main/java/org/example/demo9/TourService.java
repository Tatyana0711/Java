package org.example.demo9;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Сервисный класс для управления турами.
 */
@Service
public class TourService {
    @Autowired
    private TourRepository repo;

    /**
     * Получает список всех туров по ключевому слову.
     *
     * @param keyword ключевое слово для поиска туров (если null, возвращает все туры)
     * @return список туров, соответствующих ключевому слову
     */
    public List<Tour> getAllTours(String keyword) {
        if (keyword != null){
            return repo.search(keyword);
        }
        return repo.findAll();
    }

    /**
     * Сохраняет указанный тур в репозитории.
     *
     * @param tour объект тура для сохранения
     */
    public void save(Tour tour) {
        repo.save(tour);
    }

    /**
     * Получает тур по его идентификатору.
     *
     * @param id идентификатор тура
     * @return объект тура с указанным идентификатором
     */
    public Tour get(Integer id) {
        return repo.findById(id).get();
    }

    /**
     * Удаляет тур по его идентификатору.
     *
     * @param id идентификатор тура для удаления
     */
    public void delete(Integer id) {
        repo.deleteById(id);
    }

    /**
     * Вычисляет среднюю цену для списка туров.
     *
     * @param tours список туров, для которых необходимо вычислить среднюю цену
     * @return средняя цена туров, или 0.0, если список пуст
     */
    public double calculateAveragePrice(List<Tour> tours) {
        return tours.stream()
                .mapToDouble(Tour::getPrice)
                .average()
                .orElse(0.0);
    }

    /**
     * Получает количество туров в разрезе транспортных средств.
     *
     * @param tours список туров, для которых необходимо подсчитать количество по видам транспорта
     * @return карта, где ключом является тип транспорта, а значением — общее количество туров,
     *         использующих этот тип транспорта
     */
    public Map<String, Long> getCountsByTransport(List<Tour> tours) {
        return tours.stream()
                .collect(Collectors.groupingBy(Tour::getTransport, Collectors.counting()));
    }
}

