package org.example.demo9;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Репозиторий для обработки данных о турах.
 * <p>
 * Этот интерфейс расширяет {@link JpaRepository} и предоставляет
 * методы для доступа к объектам {@link Tour} в базе данных.
 * </p>
 */
@Repository
public interface TourRepository extends JpaRepository<Tour, Integer> {

    /**
     * Ищет туры по ключевому слову.
     * <p>
     * Этот метод выполняет поиск туров, полные данные которых
     * содержат данное ключевое слово. Поиск осуществляется по
     * всем полям тура, включая ID, название, страну, город, даты
     * отправления и прибытия, цену и транспорт.
     * </p>
     *
     * @param keyword ключевое слово для фильтрации туров
     * @return список объектов {@link Tour}, соответствующих критериям поиска
     */
    @Query("SELECT p FROM Tour p WHERE CONCAT(p.ID, p.name, p.country, p.city, p.departure, p.arrival, p.price, p.transport) LIKE %?1%")
    public List<Tour> search (String keyword);
}
